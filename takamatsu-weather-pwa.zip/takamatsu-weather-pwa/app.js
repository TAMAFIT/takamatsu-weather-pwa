'use strict';

const APP_VERSION = '1.0.0';
const CACHE_KEY = 'takamatsu-weather:last-success';

// 高松市中心部付近。ピンポイント地点に変えたい場合はここを変更してください。
const LOCATION = {
  name: '高松市',
  latitude: 34.3428,
  longitude: 134.0466,
  timezone: 'Asia/Tokyo'
};

const RISK = {
  LOW: { key: 'low', label: '低', className: 'risk-low' },
  MID: { key: 'mid', label: '中', className: 'risk-mid' },
  HIGH: { key: 'high', label: '高', className: 'risk-high' }
};

const state = {
  weather: null,
  selectedDate: null,
  deferredInstallPrompt: null
};

const els = {};

document.addEventListener('DOMContentLoaded', init);

function init() {
  bindElements();
  bindEvents();
  setupClock();
  setupNetworkStatus();
  setupPwaInstall();
  registerServiceWorker();

  els.locationName.textContent = LOCATION.name;

  const cached = readCachedWeather();
  if (cached) {
    state.weather = cached;
    state.selectedDate = cached.daily?.[0]?.date || null;
    renderAll({ fromCache: true });
  }

  refreshWeather();
}

function bindElements() {
  Object.assign(els, {
    clockText: document.getElementById('clockText'),
    networkStatus: document.getElementById('networkStatus'),
    locationName: document.getElementById('locationName'),
    updatedAt: document.getElementById('updatedAt'),
    refreshButton: document.getElementById('refreshButton'),
    currentIcon: document.getElementById('currentIcon'),
    currentWeather: document.getElementById('currentWeather'),
    currentTemp: document.getElementById('currentTemp'),
    highLow: document.getElementById('highLow'),
    todayRisk: document.getElementById('todayRisk'),
    summaryComment: document.getElementById('summaryComment'),
    weeklyList: document.getElementById('weeklyList'),
    selectedDateText: document.getElementById('selectedDateText'),
    hourlyTableBody: document.getElementById('hourlyTableBody'),
    adviceList: document.getElementById('adviceList'),
    dailyCardTemplate: document.getElementById('dailyCardTemplate'),
    installCard: document.getElementById('installCard'),
    installButton: document.getElementById('installButton'),
    installHint: document.getElementById('installHint')
  });
}

function bindEvents() {
  els.refreshButton.addEventListener('click', refreshWeather);
}

function setupClock() {
  const tick = () => {
    els.clockText.textContent = new Intl.DateTimeFormat('ja-JP', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
      timeZone: LOCATION.timezone
    }).format(new Date());
  };
  tick();
  window.setInterval(tick, 30 * 1000);
}

function setupNetworkStatus() {
  const update = () => {
    const online = navigator.onLine;
    els.networkStatus.textContent = online ? 'オンライン' : 'オフライン';
    els.networkStatus.classList.toggle('offline', !online);
  };
  update();
  window.addEventListener('online', update);
  window.addEventListener('offline', update);
}

function setupPwaInstall() {
  const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  if (isStandalone) return;

  const isIOS = /iphone|ipad|ipod/i.test(window.navigator.userAgent);
  els.installCard.hidden = false;

  if (isIOS) {
    els.installHint.textContent = 'iPhoneはSafariで開き、共有ボタンから「ホーム画面に追加」を選んでください。';
  } else {
    els.installHint.textContent = 'AndroidはChromeで「インストール」または「ホーム画面に追加」を選べます。';
  }

  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    state.deferredInstallPrompt = event;
    els.installButton.hidden = false;
  });

  els.installButton.addEventListener('click', async () => {
    if (!state.deferredInstallPrompt) return;
    state.deferredInstallPrompt.prompt();
    await state.deferredInstallPrompt.userChoice;
    state.deferredInstallPrompt = null;
    els.installButton.hidden = true;
  });
}

async function registerServiceWorker() {
  if (!('serviceWorker' in navigator)) return;

  try {
    const registration = await navigator.serviceWorker.register('./sw.js');
    // 更新があれば次回起動時に反映されます。
    if (registration.waiting) return;
  } catch (error) {
    console.warn('Service worker registration failed:', error);
  }
}

async function refreshWeather() {
  setLoading(true);

  try {
    const weather = await fetchWeather();
    state.weather = weather;
    state.selectedDate = weather.daily?.[0]?.date || null;
    writeCachedWeather(weather);
    renderAll({ fromCache: false });
  } catch (error) {
    console.error(error);
    const cached = readCachedWeather();
    if (cached) {
      state.weather = cached;
      state.selectedDate = state.selectedDate || cached.daily?.[0]?.date || null;
      renderAll({ fromCache: true });
      showToast('最新データの取得に失敗しました。前回の取得データを表示しています。');
    } else {
      renderError(error);
    }
  } finally {
    setLoading(false);
  }
}

function setLoading(isLoading) {
  document.body.classList.toggle('is-loading', isLoading);
  els.refreshButton.disabled = isLoading;
  els.refreshButton.innerHTML = isLoading
    ? '<span aria-hidden="true">↻</span> 取得中'
    : '<span aria-hidden="true">↻</span> 更新する';
}

async function fetchWeather() {
  const hourly = [
    'temperature_2m',
    'relative_humidity_2m',
    'precipitation_probability',
    'precipitation',
    'weather_code',
    'wind_speed_10m',
    'wind_direction_10m'
  ].join(',');

  const daily = [
    'weather_code',
    'temperature_2m_max',
    'temperature_2m_min',
    'precipitation_probability_max',
    'precipitation_sum'
  ].join(',');

  const current = [
    'temperature_2m',
    'relative_humidity_2m',
    'precipitation',
    'weather_code',
    'wind_speed_10m',
    'wind_direction_10m'
  ].join(',');

  const url = new URL('https://api.open-meteo.com/v1/forecast');
  url.searchParams.set('latitude', String(LOCATION.latitude));
  url.searchParams.set('longitude', String(LOCATION.longitude));
  url.searchParams.set('timezone', LOCATION.timezone);
  url.searchParams.set('forecast_days', '7');
  url.searchParams.set('wind_speed_unit', 'kmh');
  url.searchParams.set('current', current);
  url.searchParams.set('hourly', hourly);
  url.searchParams.set('daily', daily);

  const response = await fetch(url.toString(), {
    method: 'GET',
    headers: { Accept: 'application/json' }
  });

  if (!response.ok) {
    throw new Error(`Open-Meteo取得エラー: ${response.status}`);
  }

  const raw = await response.json();
  return normalizeWeather(raw);
}

function normalizeWeather(raw) {
  const daily = raw.daily.time.map((date, index) => {
    const weatherCode = raw.daily.weather_code[index];
    const probability = raw.daily.precipitation_probability_max[index] ?? 0;
    const precipitation = raw.daily.precipitation_sum[index] ?? 0;
    const risk = judgeRisk({ probability, precipitation, weatherCode });

    return {
      date,
      dayName: getDayLabel(date, index),
      dateLabel: getDateLabel(date),
      weatherCode,
      weatherText: weatherCodeToText(weatherCode),
      icon: weatherCodeToIcon(weatherCode),
      tempMax: round(raw.daily.temperature_2m_max[index]),
      tempMin: round(raw.daily.temperature_2m_min[index]),
      probability,
      precipitation,
      risk
    };
  });

  const hourly = raw.hourly.time.map((time, index) => {
    const weatherCode = raw.hourly.weather_code[index];
    const probability = raw.hourly.precipitation_probability[index] ?? 0;
    const precipitation = raw.hourly.precipitation[index] ?? 0;
    const windSpeed = raw.hourly.wind_speed_10m[index] ?? 0;
    const windDeg = raw.hourly.wind_direction_10m[index];
    const risk = judgeRisk({ probability, precipitation, weatherCode, windSpeed });

    return {
      time,
      date: time.slice(0, 10),
      hour: Number(time.slice(11, 13)),
      weatherCode,
      weatherText: weatherCodeToText(weatherCode),
      icon: weatherCodeToIcon(weatherCode),
      temperature: round(raw.hourly.temperature_2m[index]),
      humidity: raw.hourly.relative_humidity_2m[index],
      probability,
      precipitation: round(precipitation, 1),
      windSpeed: round(windSpeed),
      windDirection: windDirectionToText(windDeg),
      risk
    };
  });

  const currentCode = raw.current.weather_code;
  const current = {
    time: raw.current.time,
    temperature: round(raw.current.temperature_2m),
    humidity: raw.current.relative_humidity_2m,
    precipitation: raw.current.precipitation ?? 0,
    weatherCode: currentCode,
    weatherText: weatherCodeToText(currentCode),
    icon: weatherCodeToIcon(currentCode),
    windSpeed: round(raw.current.wind_speed_10m ?? 0),
    windDirection: windDirectionToText(raw.current.wind_direction_10m)
  };

  return {
    appVersion: APP_VERSION,
    location: LOCATION,
    fetchedAt: new Date().toISOString(),
    current,
    daily,
    hourly,
    rawGenerationTimeMs: raw.generationtime_ms
  };
}

function renderAll({ fromCache = false } = {}) {
  if (!state.weather) return;
  renderSummary(fromCache);
  renderWeekly();
  renderHourly();
  renderAdvice();
}

function renderSummary(fromCache) {
  const { current, daily, fetchedAt } = state.weather;
  const today = daily[0];
  const risk = today?.risk || RISK.LOW;

  els.currentIcon.textContent = current.icon;
  els.currentWeather.textContent = current.weatherText;
  els.currentTemp.textContent = `${current.temperature}℃`;
  els.highLow.textContent = today ? `最高${today.tempMax}℃ / 最低${today.tempMin}℃` : '最高--℃ / 最低--℃';
  setRiskBadge(els.todayRisk, risk);
  els.summaryComment.textContent = buildSummaryComment(today);

  const prefix = fromCache ? '前回取得' : '最終更新';
  els.updatedAt.textContent = `${prefix} ${formatDateTime(fetchedAt)}`;
}

function renderWeekly() {
  const fragment = document.createDocumentFragment();
  const todayDate = state.weather.daily[0]?.date;

  state.weather.daily.forEach((day, index) => {
    const node = els.dailyCardTemplate.content.firstElementChild.cloneNode(true);
    node.dataset.date = day.date;
    node.setAttribute('aria-selected', day.date === state.selectedDate ? 'true' : 'false');
    node.classList.toggle('is-selected', day.date === state.selectedDate);
    node.classList.toggle('is-today', day.date === todayDate);

    node.querySelector('.day-label').textContent = day.dayName;
    node.querySelector('.date-label').textContent = day.dateLabel;
    node.querySelector('.daily-icon').textContent = day.icon;
    node.querySelector('.daily-weather').textContent = day.weatherText;
    node.querySelector('.temp-high').textContent = day.tempMax;
    node.querySelector('.temp-low').textContent = day.tempMin;
    setRiskBadge(node.querySelector('.daily-risk'), day.risk);

    node.addEventListener('click', () => {
      state.selectedDate = day.date;
      renderWeekly();
      renderHourly();
      renderAdvice();
    });

    fragment.appendChild(node);
  });

  els.weeklyList.replaceChildren(fragment);
}

function renderHourly() {
  const date = state.selectedDate || state.weather.daily[0]?.date;
  const day = state.weather.daily.find((item) => item.date === date);
  const rows = state.weather.hourly
    .filter((item) => item.date === date)
    .filter((item) => [0, 3, 6, 9, 12, 15, 18, 21].includes(item.hour));

  els.selectedDateText.textContent = day ? `${day.dayName} ${day.dateLabel}` : '--';

  if (!rows.length) {
    els.hourlyTableBody.innerHTML = '<tr><td colspan="7" class="empty-cell">この日の時間別データがありません。</td></tr>';
    return;
  }

  const html = rows.map((item) => {
    const riskClass = item.risk.className;
    return `
      <tr>
        <td class="hour-cell">${pad2(item.hour)}:00</td>
        <td><span class="weather-cell"><span class="weather-mini-icon" aria-hidden="true">${escapeHtml(item.icon)}</span>${escapeHtml(item.weatherText)}</span></td>
        <td><strong>${item.temperature}℃</strong></td>
        <td>${item.probability}%</td>
        <td>${item.precipitation.toFixed(1)}mm</td>
        <td>${escapeHtml(item.windDirection)} ${item.windSpeed}km/h</td>
        <td><span class="risk-badge ${riskClass}">${item.risk.label}</span></td>
      </tr>`;
  }).join('');

  els.hourlyTableBody.innerHTML = html;
}

function renderAdvice() {
  const selectedDate = state.selectedDate || state.weather.daily[0]?.date;
  const rows = state.weather.hourly
    .filter((item) => item.date === selectedDate)
    .filter((item) => [6, 9, 12, 15, 18, 21].includes(item.hour));

  const day = state.weather.daily.find((item) => item.date === selectedDate);
  const advice = buildAdviceList(day, rows);
  els.adviceList.innerHTML = advice.map((text) => `<li>${escapeHtml(text)}</li>`).join('');
}

function renderError(error) {
  els.updatedAt.textContent = '取得失敗';
  els.currentWeather.textContent = '取得失敗';
  els.currentTemp.textContent = '--℃';
  els.summaryComment.textContent = error?.message || '天気データを取得できませんでした。通信状態を確認してください。';
  els.weeklyList.innerHTML = '<div class="daily-card" style="min-width: 260px;">データ取得に失敗しました</div>';
  els.hourlyTableBody.innerHTML = '<tr><td colspan="7" class="empty-cell">通信状態を確認して再度更新してください。</td></tr>';
}

function judgeRisk({ probability = 0, precipitation = 0, weatherCode = 0, windSpeed = 0 }) {
  const rainCodes = new Set([51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82, 95, 96, 99]);
  const thunderCodes = new Set([95, 96, 99]);
  let score = 0;

  if (probability >= 70) score += 3;
  else if (probability >= 50) score += 2;
  else if (probability >= 30) score += 1;

  if (precipitation >= 5) score += 4;
  else if (precipitation >= 3) score += 3;
  else if (precipitation >= 1) score += 2;
  else if (precipitation > 0) score += 1;

  if (thunderCodes.has(weatherCode)) score += 4;
  else if (rainCodes.has(weatherCode)) score += 2;

  if (windSpeed >= 10) score += 1;

  if (score >= 6) return RISK.HIGH;
  if (score >= 3) return RISK.MID;
  return RISK.LOW;
}

function buildSummaryComment(today) {
  if (!today) return '更新ボタンで最新データを取得します。';

  if (today.risk.key === 'high') {
    return '雨リスク高め。外出・登山は時間帯をかなり選びたい日です。';
  }
  if (today.risk.key === 'mid') {
    return '外出は可。雨雲と時間帯を見て動くのが無難です。';
  }
  return '外出しやすい日です。予定前に一度だけ更新して確認してください。';
}

function buildAdviceList(day, rows) {
  if (!day || !rows.length) {
    return [
      'データ取得後に時間帯別の行動アドバイスを表示します。',
      '天気が変わりやすい日は、出発直前の更新がおすすめです。',
      '雷雨や強風の可能性がある場合は、公式情報も確認してください。'
    ];
  }

  const morning = rows.filter((item) => item.hour <= 12);
  const afternoon = rows.filter((item) => item.hour >= 15);
  const firstMidOrHigh = rows.find((item) => item.risk.key !== 'low');
  const highRisk = rows.find((item) => item.risk.key === 'high');
  const thunder = rows.find((item) => [95, 96, 99].includes(item.weatherCode));

  const morningMaxRisk = maxRisk(morning);
  const afternoonMaxRisk = maxRisk(afternoon);
  const advice = [];

  if (morningMaxRisk === 'low') {
    advice.push('午前中の外出はしやすいです。');
  } else if (morningMaxRisk === 'mid') {
    advice.push('午前中も小雨・にわか雨に注意してください。');
  } else {
    advice.push('午前中から雨リスクが高めです。予定変更も検討してください。');
  }

  if (firstMidOrHigh) {
    advice.push(`${pad2(firstMidOrHigh.hour)}時以降は雨リスクが上がります。`);
  } else {
    advice.push('3時間ごとの予報では大きな雨リスクは低めです。');
  }

  if (thunder) {
    advice.push('雷雨の可能性があります。日山・屋外運動は避ける判断が安全です。');
  } else if (highRisk) {
    advice.push('日山に行くなら短時間でも避けたい時間帯があります。');
  } else if (afternoonMaxRisk === 'mid') {
    advice.push('日山に行くなら短時間・早めの時間帯が無難です。');
  } else {
    advice.push('日山に行く場合も、出発直前にもう一度更新してください。');
  }

  return advice;
}

function maxRisk(items) {
  if (items.some((item) => item.risk.key === 'high')) return 'high';
  if (items.some((item) => item.risk.key === 'mid')) return 'mid';
  return 'low';
}

function setRiskBadge(element, risk) {
  element.classList.remove('risk-low', 'risk-mid', 'risk-high');
  element.classList.add(risk.className);
  element.textContent = risk.label;
}

function weatherCodeToText(code) {
  const map = {
    0: '快晴',
    1: '晴れ',
    2: '一部曇り',
    3: '曇り',
    45: '霧',
    48: '霧氷',
    51: '弱い霧雨',
    53: '霧雨',
    55: '強い霧雨',
    56: '弱い凍雨',
    57: '強い凍雨',
    61: '弱い雨',
    63: '雨',
    65: '強い雨',
    66: '弱い凍雨',
    67: '強い凍雨',
    71: '弱い雪',
    73: '雪',
    75: '強い雪',
    77: '雪粒',
    80: '弱いにわか雨',
    81: 'にわか雨',
    82: '強いにわか雨',
    85: '弱いにわか雪',
    86: '強いにわか雪',
    95: '雷雨',
    96: '雷雨・弱い雹',
    99: '雷雨・強い雹'
  };
  return map[code] || `不明:${code}`;
}

function weatherCodeToIcon(code) {
  if (code === 0 || code === 1) return '☀️';
  if (code === 2) return '🌤️';
  if (code === 3) return '☁️';
  if (code === 45 || code === 48) return '🌫️';
  if ([51, 53, 55, 56, 57].includes(code)) return '🌦️';
  if ([61, 63, 65, 66, 67, 80, 81, 82].includes(code)) return '🌧️';
  if ([71, 73, 75, 77, 85, 86].includes(code)) return '❄️';
  if ([95, 96, 99].includes(code)) return '⛈️';
  return '☁️';
}

function windDirectionToText(deg) {
  if (deg === null || deg === undefined || Number.isNaN(Number(deg))) return '-';
  const directions = [
    '北', '北北東', '北東', '東北東',
    '東', '東南東', '南東', '南南東',
    '南', '南南西', '南西', '西南西',
    '西', '西北西', '北西', '北北西'
  ];
  return directions[Math.round(Number(deg) / 22.5) % 16];
}

function getDayLabel(dateText, index) {
  if (index === 0) return '今日';
  const date = new Date(`${dateText}T00:00:00+09:00`);
  return new Intl.DateTimeFormat('ja-JP', { weekday: 'short', timeZone: LOCATION.timezone }).format(date);
}

function getDateLabel(dateText) {
  const date = new Date(`${dateText}T00:00:00+09:00`);
  const month = date.getMonth() + 1;
  const day = date.getDate();
  const weekday = new Intl.DateTimeFormat('ja-JP', { weekday: 'short', timeZone: LOCATION.timezone }).format(date);
  return `${month}/${day}（${weekday}）`;
}

function formatDateTime(value) {
  const date = new Date(value);
  return new Intl.DateTimeFormat('ja-JP', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
    timeZone: LOCATION.timezone
  }).format(date).replaceAll('/', '/');
}

function pad2(value) {
  return String(value).padStart(2, '0');
}

function round(value, digit = 0) {
  const factor = 10 ** digit;
  return Math.round(Number(value) * factor) / factor;
}

function writeCachedWeather(weather) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(weather));
  } catch (error) {
    console.warn('cache write failed:', error);
  }
}

function readCachedWeather() {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (error) {
    console.warn('cache read failed:', error);
    return null;
  }
}

function showToast(message) {
  const existing = document.querySelector('.toast');
  if (existing) existing.remove();

  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.textContent = message;
  document.body.appendChild(toast);
  window.setTimeout(() => toast.remove(), 3600);
}

function escapeHtml(value) {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}
