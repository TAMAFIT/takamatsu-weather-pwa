# 高松市 天気ダッシュボード PWA

高松市の1週間・3時間ごとの天気を確認し、外出・移動・登山判断を補助する完全静的PWAです。

- フロントのみで動作
- GASなし
- サーバーなし
- GitHub Pages対応
- Android / iPhoneのホーム画面追加対応
- Open-Meteo APIをブラウザから直接取得

## ファイル構成

```text
index.html              画面本体
style.css               UIスタイル
app.js                  Open-Meteo取得・描画・雨リスク判定
manifest.webmanifest    PWAマニフェスト
sw.js                   Service Worker
icons/                  PWAアイコン一式
```

## GitHub Pagesで公開する手順

1. このZIPを解凍する
2. GitHubで新しいリポジトリを作成する
3. 解凍した中身をリポジトリ直下にアップロードする
4. GitHubの `Settings` → `Pages` を開く
5. `Build and deployment` で `Deploy from a branch` を選ぶ
6. Branchを `main`、folderを `/root` にする
7. 発行されたURLを開く

Service WorkerとPWAはHTTPS環境が必要です。GitHub PagesはHTTPSなのでそのまま使えます。

## Androidでアプリ化する方法

1. ChromeでGitHub PagesのURLを開く
2. 画面内の「インストール」ボタン、またはChromeメニューから「アプリをインストール」「ホーム画面に追加」を選ぶ
3. ホーム画面からアプリ風に起動できます

## iPhoneでアプリ化する方法

1. SafariでGitHub PagesのURLを開く
2. 共有ボタンを押す
3. 「ホーム画面に追加」を選ぶ
4. ホーム画面からアプリ風に起動できます

※ iPhoneではChromeではなくSafariから追加するのが基本です。

## 地点を変更する方法

`app.js` の先頭付近にある `LOCATION` を変更してください。

```js
const LOCATION = {
  name: '高松市',
  latitude: 34.3428,
  longitude: 134.0466,
  timezone: 'Asia/Tokyo'
};
```

たまフィット、日山、自宅などにピンポイント化する場合は、緯度・経度を差し替えます。

## 使用しているデータ

Weather data by [Open-Meteo](https://open-meteo.com/)

Open-MeteoはAPIキー不要で使える天気APIです。利用条件・商用利用・アクセス制限はOpen-Meteo公式の条件を確認してください。

## 注意

このアプリは個人用の判断補助です。雷雨、警報、注意報、災害リスクがある場合は、気象庁などの公式情報も確認してください。
